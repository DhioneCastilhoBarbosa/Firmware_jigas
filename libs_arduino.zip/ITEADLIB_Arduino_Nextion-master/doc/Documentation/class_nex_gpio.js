var class_nex_gpio =
[
    [ "analog_write", "class_nex_gpio.html#af21eb91b041d149193bc716202d4a462", null ],
    [ "digital_read", "class_nex_gpio.html#a36386b97898f0960abda51c6010378eb", null ],
    [ "digital_write", "class_nex_gpio.html#aaea4cb428fa0a2e26927073c20ed64ac", null ],
    [ "get_pwmfreq", "class_nex_gpio.html#a8fca87ac0cdfbc8a62dec807b949c36d", null ],
    [ "pin_mode", "class_nex_gpio.html#adbe08eb11827d75c6b2e9c935d9da19a", null ],
    [ "set_pwmfreq", "class_nex_gpio.html#a62c2cb633e321ef2273eb3a7af6a5b47", null ]
];