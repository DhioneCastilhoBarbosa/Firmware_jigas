var class_nex_gauge =
[
    [ "NexGauge", "class_nex_gauge.html#ac79040067d42f7f1ba16cc4a1dfd8b9b", null ],
    [ "Get_background_color_bco", "class_nex_gauge.html#a03a6441159939961b64728dded177e92", null ],
    [ "Get_background_cropi_picc", "class_nex_gauge.html#a0a6b394a16b03beb6046ec3795d409fe", null ],
    [ "Get_font_color_pco", "class_nex_gauge.html#a830152d58485d55f475376261d52ff62", null ],
    [ "Get_pointer_thickness_wid", "class_nex_gauge.html#a50b4daf1b8dfb3cc5c329a3664341e11", null ],
    [ "getValue", "class_nex_gauge.html#aeea8933513ebba11584ad97f8c8b5e69", null ],
    [ "Set_background_color_bco", "class_nex_gauge.html#a2d2fe2d81da81e14a66260c501d644b3", null ],
    [ "Set_background_crop_picc", "class_nex_gauge.html#a223fa8a91a87439047f22ca1c33660df", null ],
    [ "Set_font_color_pco", "class_nex_gauge.html#ace00cba20b5cf5e1374c1a57bbf9a5f5", null ],
    [ "Set_pointer_thickness_wid", "class_nex_gauge.html#adacdbcb25fdf45654ebc88f572e3bce9", null ],
    [ "setValue", "class_nex_gauge.html#a448ce9ad69f54c156c325d578a96b765", null ]
];